<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c57c7d9f44             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\VisitorTracker; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->gswweykyogmsyawy(__('Visitor Tracker', PR__UTL__VISITOR_TRACKER))->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __('Visitor Tracker Setting', PR__UTL__VISITOR_TRACKER)); $this->hasLicense = false; parent::qiccuiwooiquycsg(); } }
