<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c413b5e4f6             |
    |_______________________________________|
*/
 use Pmpr\Utility\VisitorTracker\VisitorTracker; VisitorTracker::symcgieuakksimmu(); if (!function_exists('pr_utility_visitor_tracker_get_current')) { function pr_utility_visitor_tracker_get_current($aqykuigiuwmmcieu = 'object') { return VisitorTracker::symcgieuakksimmu()->ecqiugqwquemomqk($aqykuigiuwmmcieu); } } if (!function_exists('pr_utility_visitor_tracker_get_by_uuid')) { function pr_utility_visitor_tracker_get_by_uuid($eumcuksaiugmckaq, $aqykuigiuwmmcieu = 'object') { return VisitorTracker::symcgieuakksimmu()->cwgkwuemmikukkke($eumcuksaiugmckaq, '', $aqykuigiuwmmcieu); } }
